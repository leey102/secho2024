# Tailwind CSS Task Manager Dashboard UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/tirsolecointere/pen/oNwpRdd](https://codepen.io/tirsolecointere/pen/oNwpRdd).

Just a little example I did in 2 hours to practice Tailwind CSS, from a dashboard design randomly picked in Dribbble :)